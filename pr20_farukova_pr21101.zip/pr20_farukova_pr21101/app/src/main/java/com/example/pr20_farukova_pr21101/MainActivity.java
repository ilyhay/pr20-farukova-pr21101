package com.example.pr20_farukova_pr21101;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    EditText edName, edSurname,edMail;
    Button btnSave, btnRead;
    private TextView textView;

    private DatabaseReference myRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edName=findViewById(R.id.edName);
        edMail=findViewById(R.id.edMail);
        edSurname=findViewById(R.id.edSurname);
        btnSave = findViewById(R.id.btnSave);
        btnRead = findViewById(R.id.btnRaed);
        textView = findViewById(R.id.textView);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        myRef = database.getReference("путь_к_данным");

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = edName.getText().toString();
                String surname = edSurname.getText().toString();
                String mail = edMail.getText().toString();

                // Сохранение данных в Firebase
                Data data = new Data(name, surname, mail);
                myRef.setValue(data)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {
                                Toast.makeText(MainActivity.this, "Данные успешно сохранены", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {
                                Toast.makeText(MainActivity.this, "Ошибка при сохранении данных", Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });

        btnRead.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                myRef.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        Data data = dataSnapshot.getValue(Data.class);

                        if (data != null) {
                            String name = data.getName();
                            String surname = data.getSurname();
                            String mail = data.getMail();

                            String displayText = "Имя: " + name + "\nФамилия: " + surname + "\nEmail: " + mail;
                            textView.setText(displayText);
                        } else {
                            textView.setText("");
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {
                        Toast.makeText(MainActivity.this, "Ошибка при чтении данных", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
    }

    private static class Data {
        private String name;
        private String surname;
        private String mail;

        public Data() {
            // Обязательный пустой конструктор для Firebase
        }

        public Data(String name, String surname, String mail) {
            this.name = name;
            this.surname = surname;
            this.mail = mail;
        }

        public String getName() {
            return name;
        }

        public String getSurname() {
            return surname;
        }

        public String getMail() {
            return mail;
        }
    }
}